import component from './Sidebar.vue'
export default component
